from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'database.sqlite3')

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + DB_PATH
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Student(db.Model):
    __tablename__ = 'student'
    student_id = db.Column(db.Integer, primary_key=True)
    roll_number = db.Column(db.String, unique=True, nullable=False)
    first_name = db.Column(db.String, nullable=False)
    last_name = db.Column(db.String)

class Course(db.Model):
    __tablename__ = 'course'
    course_id = db.Column(db.Integer, primary_key=True)
    course_code = db.Column(db.String)
    course_name = db.Column(db.String)
    course_description = db.Column(db.String)

class Enrollment(db.Model):
    __tablename__ = 'enrollments'
    enrollment_id = db.Column(db.Integer, primary_key=True)
    estudent_id = db.Column(db.Integer)
    ecourse_id = db.Column(db.Integer)

@app.route('/')
def home():
    students = Student.query.all()
    return render_template('index.html', students=students)

@app.route('/student/create', methods=['GET', 'POST'])
def create_student():
    if request.method == 'POST':
        roll = request.form['roll']
        f_name = request.form['f_name']
        l_name = request.form['l_name']

        if Student.query.filter_by(roll_number=roll).first():
            return render_template('error.html')

        student = Student(
            roll_number=roll,
            first_name=f_name,
            last_name=l_name
        )
        db.session.add(student)
        db.session.commit()

        courses = request.form.getlist('courses')
        for c in courses:
            cid = int(c.split('_')[1])
            enroll = Enrollment(
                estudent_id=student.student_id,
                ecourse_id=cid
            )
            db.session.add(enroll)

        db.session.commit()
        return redirect(url_for('home'))

    return render_template('create.html')

@app.route('/student/<int:sid>')
def student_details(sid):
    student = Student.query.get(sid)
    enrolls = Enrollment.query.filter_by(estudent_id=sid).all()
    courses = []

    for e in enrolls:
        courses.append(Course.query.get(e.ecourse_id))

    return render_template('details.html', student=student, courses=courses)

@app.route('/student/<int:sid>/update', methods=['GET', 'POST'])
def update_student(sid):
    student = Student.query.get(sid)

    if request.method == 'POST':
        student.first_name = request.form['f_name']
        student.last_name = request.form['l_name']

        Enrollment.query.filter_by(estudent_id=sid).delete()
        courses = request.form.getlist('courses')

        for c in courses:
            cid = int(c.split('_')[1])
            db.session.add(Enrollment(estudent_id=sid, ecourse_id=cid))

        db.session.commit()
        return redirect(url_for('home'))

    return render_template('update.html', student=student)

@app.route('/student/<int:sid>/delete')
def delete_student(sid):
    Enrollment.query.filter_by(estudent_id=sid).delete()
    Student.query.filter_by(student_id=sid).delete()
    db.session.commit()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
