from flask import Flask, render_template, request
import csv
import matplotlib.pyplot as plt

app = Flask(__name__)

def read_csv():
    data = []
    with open("data.csv") as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            data.append({
                "student": row[0].strip(),
                "course": row[1].strip(),
                "marks": int(row[2])
            })
    return data


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html")

    option = request.form.get("ID")
    value = request.form.get("id_value")

    if not option or not value or not value.isdigit():
        return render_template("error.html")

    data = read_csv()

    if option == "student_id":
        rows = []
        total = 0

        for r in data:
            if r["student"] == value:
                rows.append({
                    "student": r["student"],
                    "course": r["course"],
                    "marks": r["marks"]
                })
                total += r["marks"]

        if not rows:
            return render_template("error.html")

        return render_template("student.html", rows=rows, total=total)

    elif option == "course_id":
        marks = [r["marks"] for r in data if r["course"] == value]

        if not marks:
            return render_template("error.html")

        avg = round(sum(marks) / len(marks), 2)
        maxm = max(marks)

        plt.clf()
        plt.hist(marks)
        plt.xlabel("Marks")
        plt.ylabel("Frequency")
        plt.savefig("static/hist.png")

        return render_template("course.html", avg=avg, maxm=maxm)

    return render_template("error.html")


if __name__ == "__main__":
    app.run(debug=True)
